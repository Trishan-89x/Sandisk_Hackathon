import os
import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    average_precision_score,
    confusion_matrix,
    classification_report
)


# ============================================================
# SETTINGS
# ============================================================

TRAIN_FILE = "input/train.csv"
TEST_FILE = "input/test.csv"

OUTPUT_DIR = "model_b_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

CHUNK_SIZE = 5000


# ============================================================
# BLOCK FEATURE EXTRACTION
# ============================================================

def extract_block_features(block_string):
    """
    Convert the 2000-value block signal into compact
    statistical and pattern features.

    The complete 2000-reading signal is used to derive
    features without storing the entire expanded matrix.
    """

    values = np.fromstring(block_string, sep=" ")

    if len(values) == 0:
        return np.zeros(30, dtype=np.float32)

    # Basic statistics
    mean = np.mean(values)
    std = np.std(values)

    minimum = np.min(values)
    maximum = np.max(values)

    q01 = np.percentile(values, 1)
    q05 = np.percentile(values, 5)
    q10 = np.percentile(values, 10)
    q25 = np.percentile(values, 25)
    q50 = np.percentile(values, 50)
    q75 = np.percentile(values, 75)
    q90 = np.percentile(values, 90)
    q95 = np.percentile(values, 95)
    q99 = np.percentile(values, 99)

    value_range = maximum - minimum

    # Deviation from the expected normal block mean (100)
    deviation = values - 100.0

    abs_deviation = np.abs(deviation)

    mean_abs_deviation = np.mean(abs_deviation)

    max_abs_deviation = np.max(abs_deviation)

    # Counts of unusually high/low blocks
    high_1 = np.mean(values > 115.0)
    high_2 = np.mean(values > 120.0)
    high_3 = np.mean(values > 125.0)

    low_1 = np.mean(values < 85.0)
    low_2 = np.mean(values < 80.0)
    low_3 = np.mean(values < 75.0)

    # RMS deviation
    rms_deviation = np.sqrt(
        np.mean(deviation ** 2)
    )

    # --------------------------------------------------------
    # Local / pattern information
    # --------------------------------------------------------

    # Difference between neighboring blocks
    differences = np.diff(values)

    mean_abs_difference = np.mean(
        np.abs(differences)
    )

    max_abs_difference = np.max(
        np.abs(differences)
    )

    std_difference = np.std(
        differences
    )

    # --------------------------------------------------------
    # Segment statistics
    # --------------------------------------------------------

    # Divide the 2000 blocks into 10 segments.
    # This preserves information about WHERE anomalies occur.
    n_segments = 10
    segment_size = len(values) // n_segments

    segment_means = []

    for i in range(n_segments):

        start = i * segment_size

        if i == n_segments - 1:
            end = len(values)
        else:
            end = (i + 1) * segment_size

        segment = values[start:end]

        segment_means.append(
            np.mean(segment)
        )

    segment_means = np.asarray(
        segment_means,
        dtype=np.float32
    )

    segment_mean_avg = np.mean(
        segment_means
    )

    segment_mean_std = np.std(
        segment_means
    )

    segment_mean_max = np.max(
        segment_means
    )

    segment_mean_min = np.min(
        segment_means
    )

    # --------------------------------------------------------
    # Concentration of extreme blocks
    # --------------------------------------------------------

    # Top 1% mean
    top_1_percent = np.mean(
        np.sort(values)[-max(1, len(values) // 100):]
    )

    # Bottom 1% mean
    bottom_1_percent = np.mean(
        np.sort(values)[:max(1, len(values) // 100)]
    )

    # --------------------------------------------------------
    # Return compact feature vector
    # --------------------------------------------------------

    features = [
        mean,
        std,
        minimum,
        maximum,

        q01,
        q05,
        q10,
        q25,
        q50,
        q75,
        q90,
        q95,
        q99,

        value_range,

        mean_abs_deviation,
        max_abs_deviation,

        high_1,
        high_2,
        high_3,

        low_1,
        low_2,
        low_3,

        rms_deviation,

        mean_abs_difference,
        max_abs_difference,
        std_difference,

        segment_mean_avg,
        segment_mean_std,
        segment_mean_max,
        segment_mean_min,

        top_1_percent,
        bottom_1_percent
    ]

    return np.asarray(
        features,
        dtype=np.float32
    )


# ============================================================
# FEATURE NAMES
# ============================================================

BLOCK_FEATURE_NAMES = [
    "block_mean",
    "block_std",
    "block_min",
    "block_max",

    "block_q01",
    "block_q05",
    "block_q10",
    "block_q25",
    "block_median",
    "block_q75",
    "block_q90",
    "block_q95",
    "block_q99",

    "block_range",

    "block_mean_abs_deviation",
    "block_max_abs_deviation",

    "block_high_fraction_115",
    "block_high_fraction_120",
    "block_high_fraction_125",

    "block_low_fraction_85",
    "block_low_fraction_80",
    "block_low_fraction_75",

    "block_rms_deviation",

    "block_mean_abs_difference",
    "block_max_abs_difference",
    "block_std_difference",

    "block_segment_mean",
    "block_segment_std",
    "block_segment_max",
    "block_segment_min",

    "block_top1_mean",
    "block_bottom1_mean"
]


# ============================================================
# LOAD AND PROCESS DATA
# ============================================================

def process_file(filename, output_filename):

    print("\n" + "=" * 70)
    print("Processing:", filename)
    print("=" * 70)

    first_chunk = True

    processed_chunks = []

    total_rows = 0

    for chunk in pd.read_csv(
        filename,
        chunksize=CHUNK_SIZE
    ):

        total_rows += len(chunk)

        print(
            f"Processing rows "
            f"{total_rows - len(chunk):,} "
            f"to {total_rows:,}..."
        )

        # ----------------------------------------------------
        # Only eligible dies are needed for model training
        # and evaluation.
        # ----------------------------------------------------

        chunk = chunk[
            chunk["old_label"] == 0
        ].copy()

        if len(chunk) == 0:
            continue

        # ----------------------------------------------------
        # Extract block features
        # ----------------------------------------------------

        block_features = np.vstack(
            chunk["block_readings"].map(
                extract_block_features
            ).values
        )

        block_df = pd.DataFrame(
            block_features,
            columns=BLOCK_FEATURE_NAMES,
            index=chunk.index
        )

        # ----------------------------------------------------
        # Keep identifiers, die features, spatial inputs,
        # label and block features.
        # ----------------------------------------------------

        keep_cols = (
            ["wafer_id", "die_row", "die_col"]
            + [
                c for c in chunk.columns
                if c.startswith("feature_")
            ]
            + ["old_label", "label"]
        )

        result = pd.concat(
            [
                chunk[keep_cols],
                block_df
            ],
            axis=1
        )

        processed_chunks.append(result)

        # Free unnecessary memory
        del chunk
        del block_features
        del block_df

    result = pd.concat(
        processed_chunks,
        ignore_index=True
    )

    print(
        f"\nEligible rows processed: "
        f"{len(result):,}"
    )

    print(
        f"Columns: {len(result.columns)}"
    )

    result.to_pickle(
        output_filename
    )

    print(
        "Saved:",
        output_filename
    )

    return result


# ============================================================
# SPATIAL FEATURES
# ============================================================

def add_spatial_features(df):

    print("\nCreating spatial features...")

    # Normalized row/column position
    row_min = df.groupby(
        "wafer_id"
    )["die_row"].transform("min")

    row_max = df.groupby(
        "wafer_id"
    )["die_row"].transform("max")

    col_min = df.groupby(
        "wafer_id"
    )["die_col"].transform("min")

    col_max = df.groupby(
        "wafer_id"
    )["die_col"].transform("max")

    row_range = (
        row_max - row_min
    ).replace(0, 1)

    col_range = (
        col_max - col_min
    ).replace(0, 1)

    row_norm = (
        (df["die_row"] - row_min)
        / row_range
    ).astype(np.float32)

    col_norm = (
        (df["die_col"] - col_min)
        / col_range
    ).astype(np.float32)

    row_center = row_norm - 0.5
    col_center = col_norm - 0.5

    radial_distance = np.sqrt(
        row_center ** 2 +
        col_center ** 2
    ).astype(np.float32)

    spatial = pd.DataFrame({
        "row_norm": row_norm,
        "col_norm": col_norm,
        "radial_distance": radial_distance
    }, index=df.index)

    return pd.concat(
        [df, spatial],
        axis=1
    )


# ============================================================
# MAIN
# ============================================================

print("=" * 70)
print("MODEL B - DIE + SPATIAL + BLOCK LEVEL")
print("=" * 70)


# ------------------------------------------------------------
# Process train
# ------------------------------------------------------------

train_file = os.path.join(
    OUTPUT_DIR,
    "train_block_features.pkl"
)

test_file = os.path.join(
    OUTPUT_DIR,
    "test_block_features.pkl"
)

train = process_file(
    TRAIN_FILE,
    train_file
)

test = process_file(
    TEST_FILE,
    test_file
)


# ------------------------------------------------------------
# Spatial features
# ------------------------------------------------------------

train = add_spatial_features(train)
test = add_spatial_features(test)


# ------------------------------------------------------------
# Feature groups
# ------------------------------------------------------------

die_features = [
    c for c in train.columns
    if c.startswith("feature_")
]

spatial_features = [
    "row_norm",
    "col_norm",
    "radial_distance"
]

all_features = (
    die_features
    + spatial_features
    + BLOCK_FEATURE_NAMES
)


print("\n" + "=" * 70)
print("FEATURE SUMMARY")
print("=" * 70)

print(
    "Die-level features:",
    len(die_features)
)

print(
    "Spatial features:",
    len(spatial_features)
)

print(
    "Block-derived features:",
    len(BLOCK_FEATURE_NAMES)
)

print(
    "Total model features:",
    len(all_features)
)


# ------------------------------------------------------------
# Prepare matrices
# ------------------------------------------------------------

X_train = train[
    all_features
].astype(np.float32)

y_train = train[
    "label"
].astype(np.int8)

X_test = test[
    all_features
].astype(np.float32)

y_test = test[
    "label"
].astype(np.int8)


print("\nTraining shape:", X_train.shape)
print("Testing shape :", X_test.shape)

print(
    "\nTraining failures:",
    int(y_train.sum())
)

print(
    "Testing failures:",
    int(y_test.sum())
)


# ------------------------------------------------------------
# Standardization
# ------------------------------------------------------------

print("\nStandardizing features...")

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(
    X_train
).astype(np.float32)

X_test_scaled = scaler.transform(
    X_test
).astype(np.float32)


# ------------------------------------------------------------
# Train Model B
# ------------------------------------------------------------

print("\nTraining Model B...")

model = LogisticRegression(
    class_weight="balanced",
    max_iter=300,
    solver="lbfgs"
)

model.fit(
    X_train_scaled,
    y_train
)

print("Model B training complete.")


# ------------------------------------------------------------
# Predictions
# ------------------------------------------------------------

print("\nGenerating predictions...")

probabilities = model.predict_proba(
    X_test_scaled
)[:, 1]

predictions = (
    probabilities >= 0.50
).astype(np.int8)


# ============================================================
# METRICS
# ============================================================

accuracy = accuracy_score(
    y_test,
    predictions
)

fail_precision = precision_score(
    y_test,
    predictions,
    pos_label=1,
    zero_division=0
)

fail_recall = recall_score(
    y_test,
    predictions,
    pos_label=1,
    zero_division=0
)

fail_f1 = f1_score(
    y_test,
    predictions,
    pos_label=1,
    zero_division=0
)

pass_precision = precision_score(
    y_test,
    predictions,
    pos_label=0,
    zero_division=0
)

pass_recall = recall_score(
    y_test,
    predictions,
    pos_label=0,
    zero_division=0
)

pass_f1 = f1_score(
    y_test,
    predictions,
    pos_label=0,
    zero_division=0
)

auc_pr = average_precision_score(
    y_test,
    probabilities
)

cm = confusion_matrix(
    y_test,
    predictions
)


# ============================================================
# RESULTS
# ============================================================

print("\n")
print("=" * 70)
print("MODEL B RESULTS")
print("=" * 70)

print(
    f"Accuracy          : {accuracy:.6f}"
)

print(
    f"AUC-PR            : {auc_pr:.6f}"
)

print("\nPASS CLASS")

print(
    f"Precision         : "
    f"{pass_precision:.6f}"
)

print(
    f"Recall            : "
    f"{pass_recall:.6f}"
)

print(
    f"F1                : "
    f"{pass_f1:.6f}"
)

print("\nFAIL CLASS")

print(
    f"Precision         : "
    f"{fail_precision:.6f}"
)

print(
    f"Recall            : "
    f"{fail_recall:.6f}"
)

print(
    f"F1                : "
    f"{fail_f1:.6f}"
)

print("\nConfusion Matrix")

print(cm)

print("\nClassification Report")

print(
    classification_report(
        y_test,
        predictions,
        target_names=[
            "Pass",
            "Fail"
        ],
        digits=6,
        zero_division=0
    )
)


# ============================================================
# FEATURE IMPORTANCE
# ============================================================

print("\nSaving feature importance...")

importance = pd.DataFrame({
    "feature": all_features,
    "coefficient": model.coef_[0],
    "abs_coefficient": np.abs(
        model.coef_[0]
    )
})

importance = importance.sort_values(
    "abs_coefficient",
    ascending=False
)

importance.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "model_b_feature_importance.csv"
    ),
    index=False
)


# ============================================================
# BLOCK IMPORTANCE SUMMARY
# ============================================================

block_importance = importance[
    importance["feature"].isin(
        BLOCK_FEATURE_NAMES
    )
].copy()

block_importance.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "block_feature_importance.csv"
    ),
    index=False
)


# ============================================================
# PREDICTIONS
# ============================================================

prediction_output = test[
    ["wafer_id", "die_row", "die_col"]
].copy()

prediction_output[
    "predicted_probability"
] = probabilities

prediction_output[
    "predicted_label"
] = predictions

prediction_output[
    "actual_label"
] = y_test.to_numpy()

prediction_output.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "model_b_predictions.csv"
    ),
    index=False
)


# ============================================================
# METRICS FILE
# ============================================================

metrics = pd.DataFrame({
    "metric": [
        "accuracy",
        "auc_pr",
        "pass_precision",
        "pass_recall",
        "pass_f1",
        "fail_precision",
        "fail_recall",
        "fail_f1"
    ],
    "value": [
        accuracy,
        auc_pr,
        pass_precision,
        pass_recall,
        pass_f1,
        fail_precision,
        fail_recall,
        fail_f1
    ]
})

metrics.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "model_b_metrics.csv"
    ),
    index=False
)


print("\n" + "=" * 70)
print("MODEL B COMPLETE")
print("=" * 70)

print(
    "\nAll Model B outputs are in:"
)

print(
    OUTPUT_DIR
)