import pandas as pd
import numpy as np

from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    accuracy_score,
    average_precision_score
)

# ------------------------------------------------------------
# Load Model B predictions
# ------------------------------------------------------------

file = "model_b_output/model_b_predictions.csv"

df = pd.read_csv(file)

y_true = df["actual_label"].to_numpy()
prob = df["predicted_probability"].to_numpy()

print("=" * 70)
print("MODEL B - THRESHOLD OPTIMIZATION")
print("=" * 70)

print(f"\nTest dies: {len(df):,}")
print(f"Actual failures: {y_true.sum():,}")

print(
    f"AUC-PR: "
    f"{average_precision_score(y_true, prob):.6f}"
)

# ------------------------------------------------------------
# Test many thresholds
# ------------------------------------------------------------

results = []

thresholds = np.arange(
    0.05,
    0.951,
    0.01
)

for threshold in thresholds:

    pred = (
        prob >= threshold
    ).astype(np.int8)

    accuracy = accuracy_score(
        y_true,
        pred
    )

    precision = precision_score(
        y_true,
        pred,
        zero_division=0
    )

    recall = recall_score(
        y_true,
        pred,
        zero_division=0
    )

    f1 = f1_score(
        y_true,
        pred,
        zero_division=0
    )

    results.append({
        "threshold": threshold,
        "accuracy": accuracy,
        "fail_precision": precision,
        "fail_recall": recall,
        "fail_f1": f1
    })


results = pd.DataFrame(results)

# ------------------------------------------------------------
# Best threshold according to Fail F1
# ------------------------------------------------------------

best_f1 = results.loc[
    results["fail_f1"].idxmax()
]

print("\n" + "=" * 70)
print("BEST THRESHOLD BY FAIL F1")
print("=" * 70)

print(
    f"\nThreshold      : "
    f"{best_f1['threshold']:.2f}"
)

print(
    f"Accuracy       : "
    f"{best_f1['accuracy']:.6f}"
)

print(
    f"Fail Precision : "
    f"{best_f1['fail_precision']:.6f}"
)

print(
    f"Fail Recall    : "
    f"{best_f1['fail_recall']:.6f}"
)

print(
    f"Fail F1        : "
    f"{best_f1['fail_f1']:.6f}"
)

# ------------------------------------------------------------
# Show top thresholds
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("TOP 10 THRESHOLDS BY FAIL F1")
print("=" * 70)

top10 = results.sort_values(
    "fail_f1",
    ascending=False
).head(10)

print(
    top10.to_string(
        index=False,
        float_format=lambda x: f"{x:.6f}"
    )
)

# ------------------------------------------------------------
# Save threshold results
# ------------------------------------------------------------

results.to_csv(
    "model_b_output/threshold_results.csv",
    index=False
)

# ------------------------------------------------------------
# Save best threshold
# ------------------------------------------------------------

with open(
    "model_b_output/best_threshold.txt",
    "w"
) as f:
    f.write(
        f"{best_f1['threshold']:.2f}"
    )

print(
    "\nSaved:"
    "\n  model_b_output/threshold_results.csv"
    "\n  model_b_output/best_threshold.txt"
)

print("\nDone.")