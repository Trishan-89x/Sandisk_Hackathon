import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# SETTINGS
# ============================================================

A_FILE = "model_a_output/model_a_predictions.csv"
B_FILE = "final_model_b_output/final_model_b_test_predictions.csv"

OUTPUT_DIR = "analysis_output"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# LOAD DATA
# ============================================================

print("=" * 70)
print("WAFER-LEVEL ANALYSIS")
print("=" * 70)

print("\nLoading Model A predictions...")
a = pd.read_csv(A_FILE)

print("Loading Model B predictions...")
b = pd.read_csv(B_FILE)


# ============================================================
# CHECK COLUMNS
# ============================================================

required = [
    "wafer_id",
    "die_row",
    "die_col",
    "predicted_probability",
    "predicted_label",
    "actual_label"
]

for col in required:

    if col not in a.columns:
        raise ValueError(
            f"Model A missing column: {col}"
        )

    if col not in b.columns:
        raise ValueError(
            f"Model B missing column: {col}"
        )


# ============================================================
# CHOOSE WAFERS
# ============================================================

# Choose the wafer with the largest number of eligible dies.
wafer_counts = (
    b.groupby("wafer_id")
    .size()
    .sort_values(ascending=False)
)

wafer_id = wafer_counts.index[0]

print(
    f"\nSelected representative wafer: {wafer_id}"
)

print(
    f"Eligible dies on wafer: "
    f"{wafer_counts.iloc[0]}"
)


# ============================================================
# FILTER
# ============================================================

wa = a[
    a["wafer_id"] == wafer_id
].copy()

wb = b[
    b["wafer_id"] == wafer_id
].copy()


# ============================================================
# COMMON PLOT FUNCTION
# ============================================================

def make_map(
    df,
    column,
    title,
    filename,
    cmap="viridis"
):

    plt.figure(
        figsize=(8, 8)
    )

    scatter = plt.scatter(
        df["die_col"],
        df["die_row"],
        c=df[column],
        cmap=cmap,
        s=18
    )

    plt.xlabel("Die Column")
    plt.ylabel("Die Row")
    plt.title(
        title
    )

    plt.colorbar(
        scatter,
        label=column
    )

    plt.axis("equal")

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            OUTPUT_DIR,
            filename
        ),
        dpi=200
    )

    plt.close()


# ============================================================
# ACTUAL FAILURE MAP
# ============================================================

print("\nCreating actual failure map...")

make_map(
    wb,
    "actual_label",
    f"Actual Failure Map - Wafer {wafer_id}",
    "actual_failure_map.png",
    "RdYlGn_r"
)


# ============================================================
# MODEL A PREDICTION MAP
# ============================================================

print("Creating Model A prediction map...")

make_map(
    wa,
    "predicted_label",
    f"Model A Predicted Failure Map - Wafer {wafer_id}",
    "model_a_prediction_map.png",
    "RdYlGn_r"
)


# ============================================================
# MODEL B PREDICTION MAP
# ============================================================

print("Creating Model B prediction map...")

make_map(
    wb,
    "predicted_label",
    f"Model B Predicted Failure Map - Wafer {wafer_id}",
    "model_b_prediction_map.png",
    "RdYlGn_r"
)


# ============================================================
# MODEL B PROBABILITY MAP
# ============================================================

print("Creating Model B probability map...")

make_map(
    wb,
    "predicted_probability",
    f"Model B Failure Probability - Wafer {wafer_id}",
    "model_b_probability_map.png",
    "hot"
)


# ============================================================
# FAILURE COUNTS
# ============================================================

actual_fail = int(
    wb["actual_label"].sum()
)

a_fail = int(
    wa["predicted_label"].sum()
)

b_fail = int(
    wb["predicted_label"].sum()
)


print("\n" + "=" * 70)
print("WAFER SUMMARY")
print("=" * 70)

print(
    f"Wafer ID              : {wafer_id}"
)

print(
    f"Eligible dies         : {len(wb)}"
)

print(
    f"Actual failures       : {actual_fail}"
)

print(
    f"Model A predicted     : {a_fail}"
)

print(
    f"Model B predicted     : {b_fail}"
)


# ============================================================
# SAVE SUMMARY
# ============================================================

summary = pd.DataFrame(
    {
        "wafer_id": [wafer_id],
        "eligible_dies": [len(wb)],
        "actual_failures": [actual_fail],
        "model_a_predicted_failures": [a_fail],
        "model_b_predicted_failures": [b_fail]
    }
)

summary.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "wafer_summary.csv"
    ),
    index=False
)


# ============================================================
# DONE
# ============================================================

print("\n" + "=" * 70)
print("WAFER ANALYSIS COMPLETE")
print("=" * 70)

print(
    "\nFiles saved in analysis_output:"
)

print(
    "actual_failure_map.png"
)

print(
    "model_a_prediction_map.png"
)

print(
    "model_b_prediction_map.png"
)

print(
    "model_b_probability_map.png"
)

print(
    "wafer_summary.csv"
)