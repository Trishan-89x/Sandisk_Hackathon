import os
import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    average_precision_score,
    confusion_matrix,
    classification_report
)
from scipy.ndimage import uniform_filter


# ============================================================
# SETTINGS
# ============================================================

TRAIN_FILE = "input/train.csv"
TEST_FILE = "input/test.csv"

OUTPUT_DIR = "model_a_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

WINDOW = 5


# ============================================================
# LOAD DATA
# ============================================================

print("=" * 70)
print("MODEL A - DIE LEVEL + SPATIAL CONTEXT")
print("=" * 70)

print("\nLoading training data...")

train = pd.read_csv(TRAIN_FILE)

print(f"Training rows: {len(train):,}")
print(f"Training columns: {len(train.columns):,}")

print("\nLoading test data...")

test = pd.read_csv(TEST_FILE)

print(f"Test rows: {len(test):,}")
print(f"Test columns: {len(test.columns):,}")


# ============================================================
# IDENTIFY DIE-LEVEL FEATURES
# ============================================================

feature_cols = [
    c for c in train.columns
    if c.startswith("feature_")
]

print(f"\nDie-level features found: {len(feature_cols)}")


# ============================================================
# SPATIAL FEATURE GENERATION
# ============================================================

def add_spatial_features(df):
    """
    Create spatial context from die position and pre-test failures.

    Features:
        row_norm
        col_norm
        radial_distance
        neighborhood_fail_density
        neighborhood_fail_count
        local_valid_die_count
    """

    print("Creating spatial features...")

    # Use float32 to reduce RAM
    df["row_norm"] = df["die_row"].astype(np.float32)
    df["col_norm"] = df["die_col"].astype(np.float32)

    # Normalize positions separately for every wafer
    row_min = df.groupby("wafer_id")["die_row"].transform("min")
    row_max = df.groupby("wafer_id")["die_row"].transform("max")

    col_min = df.groupby("wafer_id")["die_col"].transform("min")
    col_max = df.groupby("wafer_id")["die_col"].transform("max")

    row_range = (row_max - row_min).replace(0, 1)
    col_range = (col_max - col_min).replace(0, 1)

    df["row_norm"] = (
        (df["die_row"] - row_min) / row_range
    ).astype(np.float32)

    df["col_norm"] = (
        (df["die_col"] - col_min) / col_range
    ).astype(np.float32)

    # Center coordinates
    row_center = (
        (df["die_row"] - row_min) / row_range - 0.5
    )

    col_center = (
        (df["die_col"] - col_min) / col_range - 0.5
    )

    df["radial_distance"] = np.sqrt(
        row_center ** 2 + col_center ** 2
    ).astype(np.float32)

    # --------------------------------------------------------
    # Neighborhood context
    # --------------------------------------------------------

    df["neighborhood_fail_density"] = 0.0
    df["neighborhood_fail_count"] = 0.0
    df["local_valid_die_count"] = 0.0

    for wafer_id, idx in df.groupby("wafer_id", sort=False).groups.items():

        sub = df.loc[idx]

        max_row = int(sub["die_row"].max()) + 1
        max_col = int(sub["die_col"].max()) + 1

        old_fail_grid = np.zeros(
            (max_row, max_col),
            dtype=np.float32
        )

        valid_grid = np.zeros(
            (max_row, max_col),
            dtype=np.float32
        )

        rows = sub["die_row"].to_numpy()
        cols = sub["die_col"].to_numpy()
        old_labels = sub["old_label"].to_numpy()

        valid_grid[rows, cols] = 1.0
        old_fail_grid[rows, cols] = old_labels

        # Sum over 5x5 neighborhood
        fail_sum = uniform_filter(
            old_fail_grid,
            size=WINDOW,
            mode="constant",
            cval=0.0
        ) * (WINDOW * WINDOW)

        valid_sum = uniform_filter(
            valid_grid,
            size=WINDOW,
            mode="constant",
            cval=0.0
        ) * (WINDOW * WINDOW)

        density = np.divide(
            fail_sum,
            valid_sum,
            out=np.zeros_like(fail_sum),
            where=valid_sum > 0
        )

        df.loc[idx, "neighborhood_fail_density"] = (
            density[rows, cols]
        )

        df.loc[idx, "neighborhood_fail_count"] = (
            fail_sum[rows, cols]
        )

        df.loc[idx, "local_valid_die_count"] = (
            valid_sum[rows, cols]
        )

    print("Spatial features created.")

    return df


# ============================================================
# CREATE FEATURES
# ============================================================

train = add_spatial_features(train)
test = add_spatial_features(test)


spatial_cols = [
    "row_norm",
    "col_norm",
    "radial_distance",
    "neighborhood_fail_density",
    "neighborhood_fail_count",
    "local_valid_die_count"
]

model_features = feature_cols + spatial_cols


# ============================================================
# ELIGIBLE DIES ONLY
# ============================================================

print("\nFiltering eligible dies...")

train_eligible = train[train["old_label"] == 0].copy()
test_eligible = test[test["old_label"] == 0].copy()

print(
    f"Train eligible dies: "
    f"{len(train_eligible):,}"
)

print(
    f"Test eligible dies: "
    f"{len(test_eligible):,}"
)

print(
    f"Train newly failed: "
    f"{train_eligible['label'].sum():,}"
)

print(
    f"Test newly failed: "
    f"{test_eligible['label'].sum():,}"
)


# ============================================================
# PREPARE X / Y
# ============================================================

X_train = train_eligible[model_features].astype(
    np.float32
)

y_train = train_eligible["label"].astype(np.int8)

X_test = test_eligible[model_features].astype(
    np.float32
)

y_test = test_eligible["label"].astype(np.int8)


print("\nX_train shape:", X_train.shape)
print("X_test shape :", X_test.shape)


# ============================================================
# STANDARDIZATION
# ============================================================

print("\nStandardizing features...")

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

X_train_scaled = X_train_scaled.astype(np.float32)
X_test_scaled = X_test_scaled.astype(np.float32)


# ============================================================
# MODEL A
# ============================================================

print("\nTraining Model A...")

model = LogisticRegression(
    class_weight="balanced",
    max_iter=300,
    solver="lbfgs",
    n_jobs=-1
)

model.fit(X_train_scaled, y_train)

print("Model A training complete.")


# ============================================================
# PREDICTIONS
# ============================================================

print("\nGenerating predictions...")

probabilities = model.predict_proba(
    X_test_scaled
)[:, 1]

# Default threshold initially = 0.50
predictions = (probabilities >= 0.50).astype(np.int8)


# ============================================================
# METRICS
# ============================================================

accuracy = accuracy_score(
    y_test,
    predictions
)

fail_precision = precision_score(
    y_test,
    predictions,
    pos_label=1,
    zero_division=0
)

fail_recall = recall_score(
    y_test,
    predictions,
    pos_label=1,
    zero_division=0
)

fail_f1 = f1_score(
    y_test,
    predictions,
    pos_label=1,
    zero_division=0
)

pass_precision = precision_score(
    y_test,
    predictions,
    pos_label=0,
    zero_division=0
)

pass_recall = recall_score(
    y_test,
    predictions,
    pos_label=0,
    zero_division=0
)

pass_f1 = f1_score(
    y_test,
    predictions,
    pos_label=0,
    zero_division=0
)

auc_pr = average_precision_score(
    y_test,
    probabilities
)

cm = confusion_matrix(
    y_test,
    predictions
)


# ============================================================
# PRINT RESULTS
# ============================================================

print("\n")
print("=" * 70)
print("MODEL A RESULTS")
print("=" * 70)

print(f"Accuracy          : {accuracy:.6f}")
print(f"AUC-PR            : {auc_pr:.6f}")

print("\nPASS CLASS")
print(f"Precision         : {pass_precision:.6f}")
print(f"Recall            : {pass_recall:.6f}")
print(f"F1                : {pass_f1:.6f}")

print("\nFAIL CLASS")
print(f"Precision         : {fail_precision:.6f}")
print(f"Recall            : {fail_recall:.6f}")
print(f"F1                : {fail_f1:.6f}")

print("\nConfusion Matrix")
print(cm)

print("\nClassification Report")
print(
    classification_report(
        y_test,
        predictions,
        target_names=["Pass", "Fail"],
        digits=6,
        zero_division=0
    )
)


# ============================================================
# FEATURE IMPORTANCE
# ============================================================

print("\nSaving feature importance...")

importance = pd.DataFrame({
    "feature": model_features,
    "coefficient": model.coef_[0],
    "abs_coefficient": np.abs(model.coef_[0])
})

importance = importance.sort_values(
    "abs_coefficient",
    ascending=False
)

importance.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "model_a_feature_importance.csv"
    ),
    index=False
)


# ============================================================
# SAVE PREDICTIONS
# ============================================================

prediction_output = test_eligible[
    ["wafer_id", "die_row", "die_col"]
].copy()

prediction_output["predicted_probability"] = probabilities
prediction_output["predicted_label"] = predictions
prediction_output["actual_label"] = y_test.to_numpy()

prediction_output.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "model_a_predictions.csv"
    ),
    index=False
)


# ============================================================
# SAVE METRICS
# ============================================================

metrics = pd.DataFrame({
    "metric": [
        "accuracy",
        "auc_pr",
        "pass_precision",
        "pass_recall",
        "pass_f1",
        "fail_precision",
        "fail_recall",
        "fail_f1"
    ],
    "value": [
        accuracy,
        auc_pr,
        pass_precision,
        pass_recall,
        pass_f1,
        fail_precision,
        fail_recall,
        fail_f1
    ]
})

metrics.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "model_a_metrics.csv"
    ),
    index=False
)


print("\nModel A files saved in:")
print(OUTPUT_DIR)

print("\nDone.")