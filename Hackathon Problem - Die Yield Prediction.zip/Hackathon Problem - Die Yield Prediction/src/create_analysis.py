import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# SETTINGS
# ============================================================

MODEL_A_DIR = "model_a_output"
MODEL_B_DIR = "final_model_b_output"

OUTPUT_DIR = "analysis_output"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# HELPER
# ============================================================

def save_barplot(
    df,
    feature_col,
    value_col,
    title,
    filename,
    top_n=20
):

    data = (
        df.sort_values(
            value_col,
            ascending=False
        )
        .head(top_n)
        .sort_values(
            value_col,
            ascending=True
        )
    )

    plt.figure(figsize=(10, 8))

    plt.barh(
        data[feature_col],
        data[value_col]
    )

    plt.xlabel("Absolute coefficient")
    plt.ylabel("Feature")
    plt.title(title)

    plt.tight_layout()

    plt.savefig(
        os.path.join(
            OUTPUT_DIR,
            filename
        ),
        dpi=200
    )

    plt.close()


# ============================================================
# LOAD FEATURE IMPORTANCE
# ============================================================

print("=" * 70)
print("CREATING HACKATHON ANALYSIS")
print("=" * 70)


print("\nLoading Model A feature importance...")

model_a_imp = pd.read_csv(
    os.path.join(
        MODEL_A_DIR,
        "model_a_feature_importance.csv"
    )
)

print(
    f"Model A features: "
    f"{len(model_a_imp)}"
)


print("\nLoading Model B feature importance...")

model_b_imp = pd.read_csv(
    os.path.join(
        MODEL_B_DIR,
        "final_model_b_feature_importance.csv"
    )
)

print(
    f"Model B features: "
    f"{len(model_b_imp)}"
)


# ============================================================
# MODEL A FEATURE IMPORTANCE
# ============================================================

print("\nCreating Model A feature importance plot...")

save_barplot(
    model_a_imp,
    "feature",
    "abs_coefficient",
    "Model A - Top 20 Feature Importance",
    "model_a_feature_importance.png",
    20
)


# ============================================================
# MODEL B FEATURE IMPORTANCE
# ============================================================

print("Creating Model B feature importance plot...")

save_barplot(
    model_b_imp,
    "feature",
    "abs_coefficient",
    "Model B - Top 20 Feature Importance",
    "model_b_feature_importance.png",
    20
)


# ============================================================
# BLOCK FEATURE IMPORTANCE
# ============================================================

block_file = os.path.join(
    MODEL_B_DIR,
    "final_model_b_block_importance.csv"
)

if os.path.exists(block_file):

    print("Creating block feature importance plot...")

    block_imp = pd.read_csv(
        block_file
    )

    save_barplot(
        block_imp,
        "feature",
        "abs_coefficient",
        "Model B - Block-Level Feature Importance",
        "block_feature_importance.png",
        20
    )


# ============================================================
# MODEL COMPARISON
# ============================================================

print("\nLoading model metrics...")

model_a_metrics = pd.read_csv(
    os.path.join(
        MODEL_A_DIR,
        "model_a_metrics.csv"
    )
)

model_b_metrics = pd.read_csv(
    os.path.join(
        MODEL_B_DIR,
        "final_model_b_metrics.csv"
    )
)


# Convert metric files to dictionaries
def metrics_to_dict(df):

    return dict(
        zip(
            df.iloc[:, 0],
            df.iloc[:, 1]
        )
    )


a = metrics_to_dict(
    model_a_metrics
)

b = metrics_to_dict(
    model_b_metrics
)


# Create comparison table
comparison = pd.DataFrame(
    {
        "Metric": [
            "Accuracy",
            "AUC-PR",
            "Fail Precision",
            "Fail Recall",
            "Fail F1"
        ],
        "Model A": [
            a.get("accuracy", np.nan),
            a.get("auc_pr", np.nan),
            a.get("fail_precision", np.nan),
            a.get("fail_recall", np.nan),
            a.get("fail_f1", np.nan)
        ],
        "Model B": [
            b.get("accuracy", np.nan),
            b.get("auc_pr", np.nan),
            b.get("fail_precision", np.nan),
            b.get("fail_recall", np.nan),
            b.get("fail_f1", np.nan)
        ]
    }
)


comparison["Improvement"] = (
    comparison["Model B"]
    -
    comparison["Model A"]
)


comparison.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "model_comparison.csv"
    ),
    index=False
)


print(
    "\n" + "=" * 70
)

print(
    "MODEL COMPARISON"
)

print(
    "=" * 70
)

print(
    comparison.to_string(
        index=False
    )
)


# ============================================================
# MODEL COMPARISON PLOT
# ============================================================

metrics = [
    "AUC-PR",
    "Fail F1",
    "Fail Precision",
    "Fail Recall"
]

a_values = []
b_values = []

for metric in metrics:

    row = comparison[
        comparison["Metric"] == metric
    ].iloc[0]

    a_values.append(
        row["Model A"]
    )

    b_values.append(
        row["Model B"]
    )


x = np.arange(
    len(metrics)
)

width = 0.35

plt.figure(
    figsize=(10, 6)
)

plt.bar(
    x - width / 2,
    a_values,
    width,
    label="Model A"
)

plt.bar(
    x + width / 2,
    b_values,
    width,
    label="Model B"
)

plt.xticks(
    x,
    metrics
)

plt.ylabel("Score")
plt.title(
    "Model A vs Model B"
)

plt.legend()

plt.tight_layout()

plt.savefig(
    os.path.join(
        OUTPUT_DIR,
        "model_a_vs_model_b.png"
    ),
    dpi=200
)

plt.close()


# ============================================================
# TEST PREDICTIONS
# ============================================================

print("\nLoading Model A predictions...")

pred_a = pd.read_csv(
    os.path.join(
        MODEL_A_DIR,
        "model_a_predictions.csv"
    )
)

print(
    "Model A prediction columns:"
)

print(
    list(pred_a.columns)
)


print("\nLoading Model B predictions...")

pred_b = pd.read_csv(
    os.path.join(
        MODEL_B_DIR,
        "final_model_b_test_predictions.csv"
    )
)

print(
    "Model B prediction columns:"
)

print(
    list(pred_b.columns)
)


# ============================================================
# BASIC PREDICTION SUMMARY
# ============================================================

summary = pd.DataFrame(
    {
        "Model": [
            "Model A",
            "Model B"
        ],
        "Test dies": [
            len(pred_a),
            len(pred_b)
        ],
        "Predicted failures": [
            int(
                pred_a["predicted_label"].sum()
            ),
            int(
                pred_b["predicted_label"].sum()
            )
        ],
        "Actual failures": [
            int(
                pred_a["actual_label"].sum()
            ),
            int(
                pred_b["actual_label"].sum()
            )
        ]
    }
)


summary.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "prediction_summary.csv"
    ),
    index=False
)


print(
    "\n" + "=" * 70
)

print(
    "PREDICTION SUMMARY"
)

print(
    "=" * 70
)

print(
    summary.to_string(
        index=False
    )
)


# ============================================================
# WAFER MAP FUNCTION
# ============================================================

def wafer_map(
    df,
    wafer_id,
    filename,
    title
):

    wafer = df[
        df["wafer_id"] == wafer_id
    ].copy()

    if len(wafer) == 0:

        print(
            f"No data for wafer {wafer_id}"
        )

        return

    # Plot predicted/actual state
    plt.figure(
        figsize=(8, 8)
    )

    scatter = plt.scatter(
        wafer["die_col"],
        wafer["die_row"],
        c=wafer["predicted_label"],
        cmap="RdYlGn_r",
        s=12
    )

    plt.xlabel("Die Column")
    plt.ylabel("Die Row")
    plt.title(
        f"{title}\nWafer: {wafer_id}"
    )

    plt.colorbar(
        scatter,
        label="Predicted failure"
    )

    plt.axis("equal")
    plt.tight_layout()

    plt.savefig(
        os.path.join(
            OUTPUT_DIR,
            filename
        ),
        dpi=200
    )

    plt.close()


# ============================================================
# SELECT A REPRESENTATIVE WAFER
# ============================================================

if "wafer_id" in pred_b.columns:

    wafer_counts = (
        pred_b["wafer_id"]
        .value_counts()
    )

    representative_wafer = (
        wafer_counts.index[0]
    )

    print(
        "\nCreating representative "
        "Model B wafer map..."
    )

    wafer_map(
        pred_b,
        representative_wafer,
        "model_b_wafer_map.png",
        "Model B Predicted Failure Map"
    )


# ============================================================
# SAVE TOP FEATURE TABLES
# ============================================================

model_b_imp.sort_values(
    "abs_coefficient",
    ascending=False
).head(30).to_csv(
    os.path.join(
        OUTPUT_DIR,
        "model_b_top30_features.csv"
    ),
    index=False
)


if os.path.exists(block_file):

    block_imp.sort_values(
        "abs_coefficient",
        ascending=False
    ).head(30).to_csv(
        os.path.join(
            OUTPUT_DIR,
            "model_b_top30_block_features.csv"
        ),
        index=False
    )


# ============================================================
# DONE
# ============================================================

print(
    "\n" + "=" * 70
)

print(
    "ANALYSIS COMPLETE"
)

print(
    "=" * 70
)

print(
    "\nAll analysis files saved in:"
)

print(
    OUTPUT_DIR
)