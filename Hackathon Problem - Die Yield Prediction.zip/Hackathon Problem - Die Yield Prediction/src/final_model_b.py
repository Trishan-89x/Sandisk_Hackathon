import os
import numpy as np
import pandas as pd

from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    average_precision_score,
    confusion_matrix
)


# ============================================================
# SETTINGS
# ============================================================

TRAIN_FILE = "model_b_output/train_block_features.pkl"
TEST_FILE = "model_b_output/test_block_features.pkl"

OUTPUT_DIR = "final_model_b_output"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# SPATIAL FEATURES
# ============================================================

def add_spatial_features(df):

    print("Adding spatial features...")

    # Find wafer boundaries
    row_min = df.groupby(
        "wafer_id"
    )["die_row"].transform("min")

    row_max = df.groupby(
        "wafer_id"
    )["die_row"].transform("max")

    col_min = df.groupby(
        "wafer_id"
    )["die_col"].transform("min")

    col_max = df.groupby(
        "wafer_id"
    )["die_col"].transform("max")

    # Avoid division by zero
    row_range = (
        row_max - row_min
    ).replace(0, 1)

    col_range = (
        col_max - col_min
    ).replace(0, 1)

    # Normalize die position within wafer
    row_norm = (
        (df["die_row"] - row_min)
        / row_range
    ).astype(np.float32)

    col_norm = (
        (df["die_col"] - col_min)
        / col_range
    ).astype(np.float32)

    # Distance from wafer center
    row_center = row_norm - 0.5
    col_center = col_norm - 0.5

    radial_distance = np.sqrt(
        row_center ** 2 +
        col_center ** 2
    ).astype(np.float32)

    spatial = pd.DataFrame(
        {
            "row_norm": row_norm,
            "col_norm": col_norm,
            "radial_distance": radial_distance
        },
        index=df.index
    )

    return pd.concat(
        [df, spatial],
        axis=1
    )


# ============================================================
# START
# ============================================================

print("=" * 70)
print("FINAL MODEL B - RIGOROUS THRESHOLD OPTIMIZATION")
print("=" * 70)


# ============================================================
# LOAD PROCESSED DATA
# ============================================================

print("\nLoading processed training data...")

train = pd.read_pickle(
    TRAIN_FILE
)

print(
    f"Training rows: {len(train):,}"
)


print("\nLoading processed test data...")

test = pd.read_pickle(
    TEST_FILE
)

print(
    f"Test rows: {len(test):,}"
)


# ============================================================
# ADD SPATIAL FEATURES
# ============================================================

train = add_spatial_features(
    train
)

test = add_spatial_features(
    test
)


# ============================================================
# FEATURE LIST
# ============================================================

die_features = [
    c for c in train.columns
    if c.startswith("feature_")
]

block_features = [
    c for c in train.columns
    if c.startswith("block_")
]

spatial_features = [
    "row_norm",
    "col_norm",
    "radial_distance"
]

features = (
    die_features
    + spatial_features
    + block_features
)


print("\n" + "=" * 70)
print("FEATURE SUMMARY")
print("=" * 70)

print(
    "Die-level :",
    len(die_features)
)

print(
    "Spatial   :",
    len(spatial_features)
)

print(
    "Block     :",
    len(block_features)
)

print(
    "Total     :",
    len(features)
)


# ============================================================
# PREPARE TRAINING DATA
# ============================================================

X = train[
    features
].astype(np.float32)

y = train[
    "label"
].astype(np.int8)

groups = train[
    "wafer_id"
]


# ============================================================
# WAFER-LEVEL TRAIN / VALIDATION SPLIT
# ============================================================

print(
    "\nCreating wafer-level "
    "train/validation split..."
)

splitter = GroupShuffleSplit(
    n_splits=1,
    test_size=0.20,
    random_state=42
)

train_idx, val_idx = next(
    splitter.split(
        X,
        y,
        groups=groups
    )
)


X_train = X.iloc[
    train_idx
]

y_train = y.iloc[
    train_idx
]

X_val = X.iloc[
    val_idx
]

y_val = y.iloc[
    val_idx
]


print(
    f"Training dies     : "
    f"{len(X_train):,}"
)

print(
    f"Validation dies   : "
    f"{len(X_val):,}"
)

print(
    f"Training wafers   : "
    f"{groups.iloc[train_idx].nunique()}"
)

print(
    f"Validation wafers : "
    f"{groups.iloc[val_idx].nunique()}"
)

print(
    f"\nTraining failures   : "
    f"{int(y_train.sum()):,}"
)

print(
    f"Validation failures : "
    f"{int(y_val.sum()):,}"
)


# ============================================================
# STANDARDIZATION
# ============================================================

print(
    "\nStandardizing features..."
)

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(
    X_train
).astype(np.float32)

X_val_scaled = scaler.transform(
    X_val
).astype(np.float32
)


# ============================================================
# TRAIN MODEL
# ============================================================

print(
    "\nTraining Model B..."
)

model = LogisticRegression(
    class_weight="balanced",
    max_iter=300,
    solver="lbfgs"
)

model.fit(
    X_train_scaled,
    y_train
)

print(
    "Training complete."
)


# ============================================================
# VALIDATION PREDICTIONS
# ============================================================

print(
    "\nGenerating validation probabilities..."
)

val_prob = model.predict_proba(
    X_val_scaled
)[:, 1]


val_auc_pr = average_precision_score(
    y_val,
    val_prob
)

print(
    f"Validation AUC-PR: "
    f"{val_auc_pr:.6f}"
)


# ============================================================
# THRESHOLD SEARCH
# ============================================================

print(
    "\nSearching for best threshold..."
)

thresholds = np.arange(
    0.05,
    0.951,
    0.01
)

results = []


for threshold in thresholds:

    pred = (
        val_prob >= threshold
    ).astype(np.int8)

    precision = precision_score(
        y_val,
        pred,
        pos_label=1,
        zero_division=0
    )

    recall = recall_score(
        y_val,
        pred,
        pos_label=1,
        zero_division=0
    )

    f1 = f1_score(
        y_val,
        pred,
        pos_label=1,
        zero_division=0
    )

    accuracy = accuracy_score(
        y_val,
        pred
    )

    results.append(
        [
            threshold,
            accuracy,
            precision,
            recall,
            f1
        ]
    )


threshold_df = pd.DataFrame(
    results,
    columns=[
        "threshold",
        "accuracy",
        "fail_precision",
        "fail_recall",
        "fail_f1"
    ]
)


# Sort by Fail F1
threshold_df = threshold_df.sort_values(
    "fail_f1",
    ascending=False
)


best = threshold_df.iloc[0]

best_threshold = float(
    best["threshold"]
)


# ============================================================
# BEST VALIDATION RESULT
# ============================================================

print(
    "\n" + "=" * 70
)

print(
    "BEST VALIDATION THRESHOLD"
)

print(
    "=" * 70
)

print(
    f"Threshold       : "
    f"{best_threshold:.2f}"
)

print(
    f"Accuracy        : "
    f"{best['accuracy']:.6f}"
)

print(
    f"Fail Precision  : "
    f"{best['fail_precision']:.6f}"
)

print(
    f"Fail Recall     : "
    f"{best['fail_recall']:.6f}"
)

print(
    f"Fail F1         : "
    f"{best['fail_f1']:.6f}"
)

print(
    f"AUC-PR          : "
    f"{val_auc_pr:.6f}"
)


# Save threshold results
threshold_df.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "validation_thresholds.csv"
    ),
    index=False
)


# ============================================================
# RETRAIN FINAL MODEL USING ALL TRAINING DATA
# ============================================================

print(
    "\nRetraining final Model B "
    "using all training data..."
)


scaler_final = StandardScaler()

X_all_scaled = scaler_final.fit_transform(
    X
).astype(np.float32)


final_model = LogisticRegression(
    class_weight="balanced",
    max_iter=300,
    solver="lbfgs"
)

final_model.fit(
    X_all_scaled,
    y
)

print(
    "Final training complete."
)


# ============================================================
# PREPARE TEST DATA
# ============================================================

X_test = test[
    features
].astype(np.float32)

y_test = test[
    "label"
].astype(np.int8)


X_test_scaled = scaler_final.transform(
    X_test
).astype(np.float32)


# ============================================================
# FINAL TEST PREDICTIONS
# ============================================================

print(
    "\nEvaluating on test data..."
)

test_prob = final_model.predict_proba(
    X_test_scaled
)[:, 1]


test_pred = (
    test_prob >= best_threshold
).astype(np.int8)


# ============================================================
# FINAL METRICS
# ============================================================

accuracy = accuracy_score(
    y_test,
    test_pred
)

fail_precision = precision_score(
    y_test,
    test_pred,
    pos_label=1,
    zero_division=0
)

fail_recall = recall_score(
    y_test,
    test_pred,
    pos_label=1,
    zero_division=0
)

fail_f1 = f1_score(
    y_test,
    test_pred,
    pos_label=1,
    zero_division=0
)

auc_pr = average_precision_score(
    y_test,
    test_prob
)

cm = confusion_matrix(
    y_test,
    test_pred
)


# ============================================================
# FINAL RESULTS
# ============================================================

print(
    "\n" + "=" * 70
)

print(
    "FINAL MODEL B TEST RESULTS"
)

print(
    "=" * 70
)

print(
    f"Threshold       : "
    f"{best_threshold:.2f}"
)

print(
    f"Accuracy        : "
    f"{accuracy:.6f}"
)

print(
    f"AUC-PR          : "
    f"{auc_pr:.6f}"
)

print(
    f"Fail Precision  : "
    f"{fail_precision:.6f}"
)

print(
    f"Fail Recall     : "
    f"{fail_recall:.6f}"
)

print(
    f"Fail F1         : "
    f"{fail_f1:.6f}"
)

print(
    "\nConfusion Matrix"
)

print(
    cm
)


# ============================================================
# SAVE METRICS
# ============================================================

metrics = pd.DataFrame(
    {
        "metric": [
            "threshold",
            "accuracy",
            "auc_pr",
            "fail_precision",
            "fail_recall",
            "fail_f1"
        ],
        "value": [
            best_threshold,
            accuracy,
            auc_pr,
            fail_precision,
            fail_recall,
            fail_f1
        ]
    }
)


metrics.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "final_model_b_metrics.csv"
    ),
    index=False
)


# ============================================================
# SAVE TEST PREDICTIONS
# ============================================================

predictions = test[
    [
        "wafer_id",
        "die_row",
        "die_col"
    ]
].copy()


predictions[
    "predicted_probability"
] = test_prob


predictions[
    "predicted_label"
] = test_pred


predictions[
    "actual_label"
] = y_test.to_numpy()


predictions.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "final_model_b_test_predictions.csv"
    ),
    index=False
)


# ============================================================
# FEATURE IMPORTANCE
# ============================================================

importance = pd.DataFrame(
    {
        "feature": features,
        "coefficient": final_model.coef_[0],
        "abs_coefficient": np.abs(
            final_model.coef_[0]
        )
    }
)


importance = importance.sort_values(
    "abs_coefficient",
    ascending=False
)


importance.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "final_model_b_feature_importance.csv"
    ),
    index=False
)


# ============================================================
# BLOCK FEATURE IMPORTANCE
# ============================================================

block_importance = importance[
    importance["feature"].isin(
        block_features
    )
].copy()


block_importance.to_csv(
    os.path.join(
        OUTPUT_DIR,
        "final_model_b_block_importance.csv"
    ),
    index=False
)


# ============================================================
# SAVE BEST THRESHOLD
# ============================================================

with open(
    os.path.join(
        OUTPUT_DIR,
        "best_threshold.txt"
    ),
    "w"
) as f:

    f.write(
        f"{best_threshold:.4f}\n"
    )


# ============================================================
# DONE
# ============================================================

print(
    "\n" + "=" * 70
)

print(
    "FINAL MODEL B COMPLETE"
)

print(
    "=" * 70
)

print(
    "\nResults saved in:"
)

print(
    OUTPUT_DIR
)

print(
    "\nDone."
)